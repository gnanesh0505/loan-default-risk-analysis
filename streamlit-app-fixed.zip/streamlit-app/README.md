# Loan Default Risk Analysis — Streamlit App

**Project:** RISK-2024-001 | QuickLend Digital Finance  
**Author:** Gnanesh  
**Built with:** Python · Streamlit · Pandas · Matplotlib · Seaborn

---

## What This App Does

This is a complete Credit Risk Monitoring Dashboard built as a Streamlit web app. It demonstrates a Business Analyst's end-to-end Loan Default Risk Analysis project.

**5 pages:**
| Page | What you can do |
|------|----------------|
| 🏠 Portfolio Overview | Live KPI cards, alert threshold slider, default rate trend |
| 📊 Segment Analysis | Default rates by Grade, DTI, Income, Purpose, Verification |
| 📅 Vintage Analysis | Heatmap by origination year × month, festive season detection |
| 🔮 Scenario Analysis | Interactive policy simulator (DTI cutoff, grade suspension) |
| 📁 BA Documents | Full BA artifacts: Charter, BRD, FRD, User Stories, Data Dict |

---

## Run Locally (on your computer)

### Step 1 — Install Python (if not installed)
Download from https://www.python.org/downloads/ (Python 3.9 or higher)

### Step 2 — Install dependencies
Open Terminal / Command Prompt, navigate to this folder, and run:
```bash
pip install -r requirements.txt
```

### Step 3 — Run the app
```bash
streamlit run app.py
```

The app will open automatically in your browser at http://localhost:8501

---

## Deploy on Streamlit Cloud (FREE — gets you a public link)

### Step 1 — Push to GitHub
1. Create a new GitHub repository (e.g. `loan-default-risk-app`)
2. Upload all files in this folder to that repository
3. Make sure `app.py` and `requirements.txt` are in the **root** of the repo

### Step 2 — Deploy on Streamlit Cloud
1. Go to **https://share.streamlit.io**
2. Sign in with your GitHub account
3. Click **"New app"**
4. Select your repository
5. Set **Main file path** to: `app.py`
6. Click **"Deploy!"**

That's it! You'll get a free public URL like:  
`https://your-name-loan-default-app.streamlit.app`

### Step 3 — Share it
Copy the URL and add it to:
- Your GitHub repository README
- Your LinkedIn profile
- Your resume / portfolio

---

## Use Real Kaggle Data (Optional Upgrade)

By default, the app uses **synthetic data** — it works out of the box with no downloads.

To use the real Lending Club dataset:

1. Download from: https://www.kaggle.com/datasets/wordsforthewise/lending-club
2. Run the cleaning script from the main project:
   ```bash
   python ../src/clean_data.py --input accepted_loans.csv --output loans_clean.csv
   ```
3. In `app.py`, find the line:
   ```python
   df_full = generate_data()
   ```
   Replace with:
   ```python
   df_full = pd.read_csv("loans_clean.csv")
   ```

---

## File Structure

```
streamlit-app/
├── app.py                  ← Main Streamlit app (run this)
├── requirements.txt        ← Python package list (for pip and Streamlit Cloud)
├── README.md               ← This file
└── .streamlit/
    └── config.toml         ← App theme and server settings
```

---

## Tech Stack

| Tool | Purpose |
|------|---------|
| Streamlit | Web framework — turns Python into a web app |
| Pandas | Data manipulation |
| NumPy | Numerical computations + synthetic data generation |
| Matplotlib | Charts and visualizations |
| Seaborn | Heatmap (vintage analysis) |

---

## Project Links

- Full project repo: Upload the `loan-default-risk-analysis/` folder to GitHub
- Dataset: https://www.kaggle.com/datasets/wordsforthewise/lending-club

---

*Gnanesh · Loan Default Risk Analysis · RISK-2024-001*
